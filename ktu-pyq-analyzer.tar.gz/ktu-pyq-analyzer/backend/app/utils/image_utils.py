import cv2
import numpy as np
from pathlib import Path
from PIL import Image
import io

def crop_image_region(image_path: str, x: int, y: int, w: int, h: int, out_path: str) -> str:
    """Crop a rectangular region from an image file and save it."""
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"Cannot read image: {image_path}")
    
    ih, iw = img.shape[:2]
    # Clamp to image bounds
    x1 = max(0, x)
    y1 = max(0, y)
    x2 = min(iw, x + w)
    y2 = min(ih, y + h)
    
    cropped = img[y1:y2, x1:x2]
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(out_path, cropped)
    return out_path

def pdf_page_to_image(pdf_path: str, page_num: int, out_path: str, dpi: int = 150) -> str:
    """Convert a single PDF page to an image using pdf2image."""
    try:
        from pdf2image import convert_from_path
        pages = convert_from_path(pdf_path, dpi=dpi, first_page=page_num, last_page=page_num)
        if pages:
            pages[0].save(out_path, "PNG")
            return out_path
    except ImportError:
        # Fallback: use pypdfium2 if available
        pass
    raise RuntimeError("pdf2image not available. Install poppler-utils.")

def get_pdf_page_count(pdf_path: str) -> int:
    try:
        import pypdf
        reader = pypdf.PdfReader(pdf_path)
        return len(reader.pages)
    except Exception:
        return 1
