from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from typing import List, Optional
from pathlib import Path

from app.database.base import get_db
from app.models import Paper
from app.schemas.paper import PaperOut
from app.services.paper_service import upload_paper
from app.config import settings

router = APIRouter(prefix="/papers", tags=["Papers"])

@router.post("/upload", response_model=PaperOut, status_code=201)
async def upload(
    file: UploadFile = File(...),
    subject_name: str = Form(...),
    year: int = Form(...),
    exam_type: Optional[str] = Form(None),
    db: Session = Depends(get_db),
):
    return await upload_paper(db, file, subject_name, year, exam_type)

@router.get("", response_model=List[PaperOut])
def list_papers(
    subject_id: Optional[int] = None,
    year: Optional[int] = None,
    db: Session = Depends(get_db),
):
    q = db.query(Paper)
    if subject_id:
        q = q.filter(Paper.subject_id == subject_id)
    if year:
        q = q.filter(Paper.year == year)
    return q.order_by(Paper.uploaded_at.desc()).all()

@router.get("/{paper_id}", response_model=PaperOut)
def get_paper(paper_id: int, db: Session = Depends(get_db)):
    paper = db.query(Paper).filter(Paper.id == paper_id).first()
    if not paper:
        raise HTTPException(404, "Paper not found")
    return paper

@router.delete("/{paper_id}", status_code=204)
def delete_paper(paper_id: int, db: Session = Depends(get_db)):
    paper = db.query(Paper).filter(Paper.id == paper_id).first()
    if not paper:
        raise HTTPException(404, "Paper not found")
    db.delete(paper)
    db.commit()
